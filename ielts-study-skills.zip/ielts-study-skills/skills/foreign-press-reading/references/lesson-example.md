# 英中对照精读示例

用于校准版式、简注与深讲的分工，以及背景如何回到原句。下方是基于用户提供的六段英文及既有参考精读完成的开发稿，不属于盲测，也不作为学习效果证明。新文章应重新选点，不沿用此例的固定段数、五个词目或政治背景。

---

# BBC 外刊精读｜微短剧的流行与争议

*China cracks down on soft porn, violence and materialism in viral micro dramas*

中国整治爆红微短剧中的软色情、暴力和拜金内容。

本课采用所提供的六段英文节选，面向进阶学习者，按约 25 分钟组织。每段先读英文，再对照翻译和讲解。报道来源为 [BBC](https://www.bbc.com/news/articles/clypy34pj6yo)，所用选段与[公众号文章](https://mp.weixin.qq.com/s/2SJEuZI1dsGZLgB09gOBgA)中的英文范围一致。

## 先抓住文章的问题

为什么一种迅速走红的娱乐形式，会成为整治对象？这六段先写监管行动及其范围，再解释短剧的内容特点与争议。阅读时，把“监管关注什么”和“剧情怎样吸引观众”联系起来。

标题里的 **viral** 用病毒传播的速度作比喻，表示迅速走红；**materialism** 在这里指重金钱、重物质享受的价值倾向，可译为“拜金”。这两处看懂本句义即可。

## 逐段带读

### 1. 谁在行动，整治什么？

> China has ordered provincial authorities to crack down on materialistic, violent and sexualised content in locally produced micro dramas.

中国已要求省级主管部门严厉整治本土制作的微短剧中的拜金、暴力和性化内容。

**provincial authorities** 指省级主管部门；**locally produced** 在报道中国这一语境中，指本土制作的。**sexualised** 表示被赋予或强化了性意味，着重描述内容的呈现方式。

整句先抓住“要求谁做什么”：中国政府提出要求，省级主管部门负责行动，动作后面接整治对象。这样，开头的监管层级与行动范围就清楚了。

**crack down on …** 是本课值得记住的搭配，表示采取严厉措施打击或整治某种行为，常见于政府、警方或其他有管理权的机构处理违规问题的语境。介词后面放整治的对象。[牛津学习词典](https://www.oxfordlearnersdictionaries.com/definition/english/crack-down)列出了这一用法。

自拟例句：

*The university is cracking down on plagiarism.*

大学正在严查抄袭。

### 2. 抽象的整治对象，具体指哪些内容？

> The campaign targets content that portrays soft pornography, "distorted views on marriage and relationships" and "ostentatious displays of wealth", said China's National Radio and Television Administration.

国家广播电视总局表示，此次行动针对呈现软色情、“扭曲的婚恋观”和“招摇炫富”的内容。

**campaign** 在这里是一项有组织的专项行动。**that portrays …** 修饰前面的内容，说明针对哪一类内容；句末才交代消息来源。读到这里，可以在心里把“广电总局表示”接回句首。

三个并列对象中，软色情指带有性暗示、但没有露骨呈现性行为的内容；**distorted** 是“被扭曲的”；**ostentatious** 突出有意向人炫耀、显摆的姿态，因此整个财富展示的短语译成“炫富”很贴切。

这一段把第一段的概括性标签具体化：看清三类对象，就能理解行动所针对的问题。

### 3. 为什么从整治短剧，谈到了社会观念？

> It comes as part of a larger effort by the Chinese government to guide social norms, including by promoting marriages and discouraging harmful ideologies from spreading online.

此次整治属于中国政府引导社会观念与行为规范的更广泛行动，其中包括鼓励结婚，以及阻止有害思想在网上传播。

**It** 承接前面的整治行动。读较长的中间部分时，先抓“更广泛的努力”，再问两件事：谁的努力？中国政府的。为了什么？引导社会观念与行为规范。句末两项举措说明这项更广泛的行动包含什么。

这里需要补上一个概念：**social norms 为什么与影视内容有关？** 社会规范也包括一个群体习以为常的行为期待，例如什么样的婚恋选择或财富展示会得到认同。监管对作品传递何种价值观的关注，能帮助我们理解报道为何把内容整治放进社会观念引导的框架。同期广电总局公告在部署治理的同时，也提出推进精品创作、提高创作质量；因此，回到原句，更广泛的努力还涉及对内容创作方向的引导。[广电总局同期公告](https://www.nrta.gov.cn/art/2026/6/3/art_114_73404.html)提供了这层背景。

这一段承担的是“放大视角”的作用：前两段说这次行动做什么，这一段说报道把它放在怎样的背景下理解。

### 4. 迅速走红，也引来批评

> Micro dramas, which are serialised, made-for-mobile clips, have exploded in popularity globally in recent years, but have drawn criticism for their often sensationalist content.

微短剧是专为手机观看而制作、以连载形式推出的短视频，近年来在全球迅速走红，但也因内容往往哗众取宠而受到批评。

插入的说明先看懂即可：**serialised** 指分集连载；**made-for-mobile** 指针对手机观看而制作。把这部分暂时放在一边，主线就是“微短剧迅速流行，但也受到批评”。**their** 指微短剧；“往往”描述的是内容特点，并非批评发生的频率。

**sensationalist** 带有批评意味，指通过夸张、刺激或耸人听闻的呈现吸引关注。它说明这里的争议集中在怎样的创作方式。[牛津学习词典](https://www.oxfordlearnersdictionaries.com/definition/english/sensationalist)也标明了这种贬义语气。

**draw criticism for …** 值得练到能主动使用。动词在这里表示“引来某种反应”，整个搭配就是“因……招致批评”。主语放被评价的政策、做法、作品或机构，介词后说明受批评的原因，可以接名词，也可以接动名词。[牛津学习词典](https://www.oxfordlearnersdictionaries.com/definition/english/criticism)收录了相应搭配。

自拟例句：

*The new attendance system drew criticism for collecting more personal data than necessary.*

新考勤系统因收集了超出必要范围的个人信息而受到批评。

前半句交代“什么受到批评”，后半句交代“为什么”。以后讨论某项技术、制度或商业做法的争议时，可以用它把评价对象与争议原因接起来。回到原文，走红与受批评并列，提醒我们同时留意吸引力和争议。

### 5. 一句话里，怎样写出剧情的多样与吸引力？

> Many shows feature wild, fast-moving plot lines, about topics ranging from secret billionaire husbands to forbidden romances, that are designed to keep viewers glued to their screens.

许多剧集的情节夸张、推进迅速，题材从隐藏富豪身份的丈夫到禁忌恋情不一而足；这些剧情安排旨在让观众一直盯着屏幕看下去。

**feature** 在这里表示“以……为主要内容”；**wild** 形容剧情夸张、离奇。先抓“许多剧集有这样的情节”，再接上中间的题材举例，最后读这些剧情安排的目的，长句就顺了。

**ranging from A to B** 是另一个值得展开的表达。本句借两类题材展示内容的跨度，意思是“包括从 A 到 B 在内的多种……”。它既能谈数值范围，也能谈事物种类；这里属于后者。[牛津学习词典](https://www.oxfordlearnersdictionaries.com/definition/english/range_2)分别列出了这两类用法。

学生可以带走的结构是：**一类事物 + ranging from A to B**。先说总类，再举两个有代表性的例子，让读者感到范围广。A 和 B 保持相称，例如都用服务项目、问题类型或具体措施。

自拟例句：

*The university offers services ranging from language classes to mental-health support.*

这所大学提供多种服务，从语言课程到心理健康支持都有。

例句先提出“服务”，再用两类服务表现其覆盖范围。以后写一个机构提供多样服务或采取多种措施时，可以用这个结构组织例子。

读回句尾，**be designed to do …** 交代目的；**keep viewers glued to their screens** 则把注意力比作被胶水粘在屏幕上，生动地说观众持续观看、舍不得移开视线。它包含“让某人保持某种状态”的结构。[牛津学习词典](https://www.oxfordlearnersdictionaries.com/definition/english/glue_2)将这种比喻用法标为非正式表达。

**这么短的剧情，怎样让人接着看？** 用一个教学假设理解：一集结束时，人物刚发现能揭穿秘密的文件，下一集才交代内容。观众为了补上信息缺口而继续看，这就是悬念的一种作用。带着这个例子回读，剧情安排与持续观看之间的联系就具体了。

### 6. 最后一句，问题内容“并不少”

> There has also been no shortage of shows portraying excessive violence or sexualised characters.

此外，描绘过度暴力场面或以性化方式呈现角色的剧集也不在少数。

**no shortage of …** 从字面上的“不缺少”表达“很多、不乏……”。这里强调问题作品并不少；它也可以用于资源丰富的语境，褒贬随上下文变化。后面的分词短语说明是怎样的剧集，**characters** 指作品中的角色。

自拟例句：

*There is no shortage of online courses; the challenge is finding one that suits your level.*

网上课程很多，难的是找到适合自己水平的一门。

这里先承认数量充足，再把问题转向适配性。原文的最后一句则是补充问题内容的例子，呼应开头的整治对象。

## 这次带走的五个表达

| 表达 | 适合什么表达需求 |
|---|---|
| crack down on … | 写某机构严厉整治某种违规或有害行为 |
| draw criticism for … | 交代某种做法受到批评及其原因 |
| 一类事物 + ranging from A to B | 用有代表性的例子表现种类或覆盖范围 |
| keep somebody glued to something | 生动描写注意力被牢牢吸引 |
| no shortage of … | 强调某物并不少，也可继续讨论质量或选择问题 |

优先练第二项和第三项：一个帮助你解释争议，一个帮助你组织例子。其他随句词义先做到回读时能认出。

## 三道自测

**1. 读懂衔接。** 第三段开头的代词指什么？这一段怎样补充前两段？

**2. 提取用法。** 补全下面的自拟句子，并说明句中的两项服务与前面总类的关系。

*The library provides support ranging ______ group workshops ______ individual advice.*

**3. 换个话题使用。** 用本课学过的搭配表达：新评分制度因给学生增加不必要的压力而受到批评。

### 参考答案

1. 指此次针对微短剧内容的整治行动。前两段说明行动及其对象，第三段把它放进引导社会观念与行为规范的更广泛背景中。

2. **from；to**。小组工作坊和个人咨询都属于图书馆提供的支持形式，两者用来表现支持方式的多样。

   图书馆提供多种支持，从小组工作坊到个人咨询都有。

3. 自拟参考译文：

   *The new grading system drew criticism for putting unnecessary pressure on students.*

   新评分制度因给学生增加不必要的压力而受到批评。

   也可用 *placing unnecessary pressure on students*。关键是交代受批评的制度，并在后半句说明原因。
