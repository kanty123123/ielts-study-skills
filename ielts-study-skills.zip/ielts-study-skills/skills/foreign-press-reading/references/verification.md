# 外刊精读核验参考

用途：配合[外刊精读 skill](../SKILL.md)，为备课时遇到的来源、语言和背景疑问提供查验入口。本文整理前面试验中实际检索或读取过的网站，不是要求每篇文章都查遍所有网站。

核验在备课时完成。学生讲义仍以逐段带读、难度匹配和适量迁移为中心，只呈现必要来源与确实影响理解的不确定性，不增加一套核验模块。

## 一、按问题选择查验步骤

| 步骤 | 要解决的问题 | 适合使用的入口 | 完成后怎样处理 |
|---|---|---|---|
| 1. 确认材料 | 原文是什么、何时发表、全文还是节选，参考稿是否处理同一段 | 原媒体、注明出处的转载、用户正文；公众号对照稿 | 先对齐段落与时间；缺文如实标出，不补写 |
| 2. 标记疑点 | 哪些问题影响学生理解或值得教授 | 先读原文，结合学习者基础与本课目标 | 列少量待查问题，不逐词启动查询 |
| 3. 查语言用法 | 本句义、词性、搭配、语域、结构或例句是否合适 | 牛津、剑桥学习词典；需要时回到原出处 | 修正讲解，决定深讲、短注还是不展开 |
| 4. 补背景、查数据 | 学生缺少什么知识，数字和研究结论来自哪里 | 原始报告、论文、机构资料、历史文件 | 用于解释具体句子；记录对象、时间、单位和来源范围 |
| 5. 回到学生稿 | 查到的材料是否值得上屏 | 对照已写讲义与教学目标 | 留下必要解释，删去与阅读无关的检索过程 |

搜索结果和摘要可以帮助定位来源。涉及关键教学判断时，应打开对应页面，确认它确实支持准备写入讲义的内容。

## 二、原文、出处与教学对照

优先阅读原媒体；原媒体无法读取时，可用明确标注出处的转载核对文本。转载页的日期不自动等于首发日期，搜索到标题也不等于已经拿到英文正文。

| 网站 | 入口或前面使用的页面 | 适合查什么 | 使用注意 |
|---|---|---|---|
| The Economist | [媒体入口](https://www.economist.com/) | 原文标题、日期、上下文及作者的论证 | 找不到原页时，明确区分原作信息与转载信息 |
| The Wall Street Journal | [媒体入口](https://www.wsj.com/) | 报道出处、作者与原文 | 前面的特斯拉案例通过注明 WSJ 来源的转载读取正文 |
| BBC | [微短剧报道入口](https://www.bbc.com/news/articles/clypy34pj6yo) | 定位原报道及版本 | 原页未能直接读取；后续英中对照以用户粘贴的六段英文为准 |
| Share Watch | [微短剧报道转载](https://sharewatch.com/wp/2026/06/05/china-cracks-down-on-violence-and-misogyny-in-viral-micro-dramas/) | 首次微短剧试验的可读文本 | 与用户后来提供的六段版本不同，不跨版本拼接成假定全文 |
| Hindustan Times | [特斯拉 Roadster 报道转载](https://www.hindustantimes.com/technology/what-tesla-s-flying-roadster-really-means-for-the-global-auto-race-101792238766723.html) | 特斯拉案例的英文文本及转载日期 | 该页标注 WSJ；背景数字仍应追到报告发布方 |
| Minnesota Star Tribune | [线上择偶文章转载](https://www.startribune.com/when-harry-clicked-on-sally-love-in-the-digital-age/491147261) | 线上择偶三段的文本与历史时间定位 | 署名 The Economist，页面日期为 2018 年 8 月 19 日；不要把其中比例当作今天的数据 |
| JBizNews | [特斯拉文章的出处页](https://jbiznews.com/what-teslas-flying-roadster-really-means-for-the-global-auto-race/) | 辅助定位作者、日期及原出处链接 | 前面读到的是出处信息页，不能将它当作已获取完整正文的证据 |
| 微信公众平台 | [特斯拉对照稿](https://mp.weixin.qq.com/s/03LJ57cyPcPJZi-bIaCouA)、[线上择偶对照稿](https://mp.weixin.qq.com/s/Ok9Y7KytFv8oZwwcwAfAPA)、[微短剧参考稿](https://mp.weixin.qq.com/s/2SJEuZI1dsGZLgB09gOBgA) | 人工精读的模块、难度、带读方式与用法选择 | 是教学比较材料；微短剧稿最终由用户粘贴提供，其附带的媒体与影视例句不当作报道正文 |

对照前，先比较英文起止段落。特斯拉试验出现过同一文章、不同选段的情况；线上择偶试验则确认了三段输入一致。模块与可读性比较应建立在可比的材料范围上。

用户已贴出完整选段时，直接以所给英文进行教学，不因原网页访问失败而重复索取。混合输入中的文章原句、参考讲解和外部例句应先分清；英中对照按文章原句组织。

## 三、语言用法：优先学习词典

| 网站 | 入口 | 优先查什么 |
|---|---|---|
| Oxford Learner’s Dictionaries | [牛津学习词典](https://www.oxfordlearnersdictionaries.com/) | 本句义项、搭配、可数性、介词、语域标签及用法例句 |
| Cambridge Dictionary | [剑桥词典](https://dictionary.cambridge.org/) | 第二来源释义、搭配、英美差异和语法说明 |

查验时：

1. 先选对条目和词性。例如带连字符的名词与不带连字符的短语动词，不能仅按拼写近似混用。
2. 把释义放回原句，确认解释的是本句用法；不要因为词典列出某义，就认定该义适用于所有语境。
3. 准备让学生学会使用的表达，再看搭配、语域及例句。判断近义表达时，关注可替换的条件，不追求一串词表。
4. 拟好迁移例句，复核句子是否自然、意义是否明确。词典例句不必全部搬进讲义。

可复用的检索方式：

- `site:oxfordlearnersdictionaries.com/definition/english "目标表达"`
- `site:dictionary.cambridge.org "目标表达"`

### 前面查过的具体条目

这些链接便于复查已有案例，不是每次精读都要加载的词表。

| 案例 | 牛津条目 |
|---|---|
| 月饼 | [indicator](https://www.oxfordlearnersdictionaries.com/definition/english/indicator)、[opt](https://www.oxfordlearnersdictionaries.com/definition/english/opt)、[plump for](https://www.oxfordlearnersdictionaries.com/definition/english/plump-for)、[judge／judging by](https://www.oxfordlearnersdictionaries.com/us/definition/english/judge_2)、[nut](https://www.oxfordlearnersdictionaries.com/definition/english/nut_1) |
| 特斯拉 | [interpret](https://www.oxfordlearnersdictionaries.com/definition/english/interpret)、[double down](https://www.oxfordlearnersdictionaries.com/definition/english/double-down)、[cry／a far cry from](https://www.oxfordlearnersdictionaries.com/definition/english/cry_2)、[nascent](https://www.oxfordlearnersdictionaries.com/definition/english/nascent)、[last](https://www.oxfordlearnersdictionaries.com/definition/english/last1_1?q=last)、[latest](https://www.oxfordlearnersdictionaries.com/definition/english/latest_1) |
| 线上择偶 | [mutual](https://www.oxfordlearnersdictionaries.com/definition/english/mutual)、[gulf](https://www.oxfordlearnersdictionaries.com/definition/english/gulf)、[filter out](https://www.oxfordlearnersdictionaries.com/definition/english/filter-out)、[boon](https://www.oxfordlearnersdictionaries.com/definition/english/boon)、[look-in](https://www.oxfordlearnersdictionaries.com/definition/english/look-in_2)、[precious（副词）](https://www.oxfordlearnersdictionaries.com/definition/english/precious_2)、[profess](https://www.oxfordlearnersdictionaries.com/definition/english/profess)、[yawn](https://www.oxfordlearnersdictionaries.com/definition/english/yawn_1) |
| 微短剧 | [crack down](https://www.oxfordlearnersdictionaries.com/definition/english/crack-down)、[criticism](https://www.oxfordlearnersdictionaries.com/definition/english/criticism)、[range](https://www.oxfordlearnersdictionaries.com/definition/english/range_2)、[glue](https://www.oxfordlearnersdictionaries.com/definition/english/glue_2)、[shortage](https://www.oxfordlearnersdictionaries.com/definition/english/shortage)、[sensationalist](https://www.oxfordlearnersdictionaries.com/definition/english/sensationalist) |

剑桥的检索曾用于定位 [useful](https://dictionary.cambridge.org/us/dictionary/english/useful)、[nut](https://dictionary.cambridge.org/us/dictionary/english/nut)、[solid](https://dictionary.cambridge.org/dictionary/english/solid)、[precious little](https://dictionary.cambridge.org/dictionary/english/precious-little) 等条目。前面部分页面没能打开正文，因此这里记录为查找入口；不能将所有条目都标成已经完成正文核验。

## 四、背景、数字与研究：追到原始资料

| 来源 | 前面实际使用的页面 | 适合解决的问题 | 核对重点 |
|---|---|---|---|
| AlixPartners | [2026 年欧洲汽车产业分析发布页](https://www.alixpartners.com/newsroom/press-release-can-europe-still-build-cars-into-the-2030s/) | 汽车制造成本、行业竞争的报告背景 | 发布日期、比较对象、成本与售价、中国品牌与中国制造的口径 |
| IEA 国际能源署 | [电动车成本竞争力分析](https://www.iea.org/reports/what-next-for-the-global-car-industry/pathways-to-global-ev-cost-competitiveness) | 电动车供应链和制造成本的机制解释 | 车型与技术假设、地区、统计年份、模型估计与已发生事实 |
| NVIDIA | [Physical AI 概念说明](https://www.nvidia.com/en-in/glossary/generative-physical-ai/) | 理解 physical AI 与机器人、自动驾驶的联系 | 可用于技术概念说明，不能单凭它证明另一家公司已实现某项能力 |
| PubMed | [2013 年网上相识与婚姻结果研究](https://pubmed.ncbi.nlm.nih.gov/23733955/) | 定位研究摘要、作者、年份、样本及原论文入口 | 数据年份、研究对象、测量方法；相关关系与因果关系；网上相识与交友 App 的范围 |
| University of Chicago News | [上述研究的校方介绍](https://news.uchicago.edu/story/meeting-online-leads-happier-more-enduring-marriages) | 辅助理解研究过程和结果 | 新闻介绍与论文摘要相互核对，关键结论回到研究本身 |
| Australian Bureau of Statistics | [Correlation and causation](https://www.abs.gov.au/statistics/understanding-statistics/statistical-terms-and-concepts/correlation-and-causation) | 查验对相关、因果及时间趋势的解释是否适当 | 它提供统计概念依据，不直接证明某一交友平台的具体效果 |
| 国家发展改革委 | [2013 年中秋、国庆期间相关历史通知](https://www.ndrc.gov.cn/fzggw/pzjg/zwjjjcz/sjdt/201308/t20130829_1216542.html) | 理解月饼、送礼与公共事务之间的历史联系 | 文件发生时间、发布范围；历史材料不直接代替现行规则 |
| 国家广播电视总局 | [2026 年 6 月微短剧专项治理公告](https://www.nrta.gov.cn/art/2026/6/3/art_114_73404.html) | 理解当时内容治理与创作方向引导的联系 | 只补足对应报道的背景，不把后来的规定倒灌进报道，也不把精读写成现行合规指南 |

处理数据与研究时，优先回答四个问题：

- **谁、何时、在哪里？** 不把特定平台或历史样本推广到所有人、所有时间。
- **比的是什么？** 数量、比例、成本、售价、车队规模、年产量等口径是否一致。
- **属于哪种信息？** 已观察结果、当事人说法、未来预测、模型估计，还是作者推断。
- **原文到底支持到哪一步？** 不把关联写成因果，也不把额外找到的相关研究冒认为作者确实引用的研究。

上述判断只在影响教学理解时进入正文，通常一两句话即可。详细样本、方法和来源差异留在备课记录。

## 五、定位过但未完成正文查验的入口

| 来源 | 前面定位到的页面 | 当时的情况与后续使用原则 |
|---|---|---|
| The New York Times | [Why Young People in China Are Buying Feelings](https://www.nytimes.com/video/world/asia/100000010988376/china-emotional-value.html) | 定位到同名视频页面，但未取得可核对的完整英文文字稿；因此该篇没有完成精读试验 |
| NobelPrize.org | [2012 年经济学奖说明](https://www.nobelprize.org/prizes/economic-sciences/2012/press-release/)、[公众解读 PDF](https://www.nobelprize.org/uploads/2018/06/popular-economicsciences2012.pdf) | 检索用于定位匹配市场背景，正文读取受限；需要时重新读取并核实，再用于具体主张 |
| PubMed Central | [婚姻研究全文入口](https://pmc.ncbi.nlm.nih.gov/articles/PMC3690854/) | 当时读取遇到验证页面，改为核对公开的 PubMed 摘要；不能把摘要核验记录写成全文已经读过 |

以上是前面试验的访问记录，不是对当前网站可用性的实时检测。遇到访问限制，不根据搜索摘要补写全文；可以换可靠来源核实具体问题，缺少原文时请用户提供正文。

## 六、参考精读页面的读取与比对

前面的两个公众号链接，网页读取工具未能打开，后通过已安装的 Defuddle 提取到了公开正文。工具只是帮助读取，不为内容质量背书。

若当前环境有 Defuddle，可用 `defuddle parse <链接> --md` 提取 Markdown；安装路径、权限和是否能联网，以实际环境为准。提取后应确认正文、段落和日期是否齐全，图片中的文字未必会被保留。

教学对照优先看：模块分配、通读可读性、难度与基础匹配、例句迁移、练习与复现。词句核验用于支撑必要判断，不把整轮比较变成找错清单。生成稿应先保存，再读取参考稿；已看过参考的重写，如实标注为开发或补测。

## 七、简短核验记录模板

仅在制作、复查或用户要求时填写，不自动加入学生讲义。

| 待查问题及原文位置 | 读过的来源与日期 | 证据支持的范围 | 处置与讲义位置 |
|---|---|---|---|
| 例：某数字指成本还是售价 | 填具体页面，区分发布日期与查阅日期 | 已确认／部分确认／未能确认，并简写依据 | 修正、保留简注、删去补充或请求缺失材料 |

记录“未能确认”比填入看似完整的来源更有用。核验完成后仍要回到教学目标：这条信息是否让学生更容易读懂，值得深讲还是只需短注。
